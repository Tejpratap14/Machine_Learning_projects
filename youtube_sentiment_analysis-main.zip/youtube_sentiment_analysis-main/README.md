# youtube_sentiment_analysis
Youtube comments sentiment analysis

1. Run cleaned_get_youtube_comments.py to get comments/use one of the comments datasets already in the repo. 
2. Play around and do stuff with comments_full_analysis.ipynb :)

Notes: 
- You need to put your developer key, which you can get from Youtube Data API: https://developers.google.com/youtube/v3
- If you wanna use colab you have to put the comments csv file onto your google drive 

Please watch video for analysis results AND THE JUICY BITS: https://www.youtube.com/watch?v=kHOVWiZKpHM
